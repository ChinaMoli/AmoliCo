<?php

namespace Qcloud\Cos\Exception;

// The specified bucket does not exist.
class NoSuchBucketException extends CosException {}
