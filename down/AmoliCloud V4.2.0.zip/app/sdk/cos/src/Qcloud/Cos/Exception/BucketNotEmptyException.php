<?php

namespace Qcloud\Cos\Exception;

// The bucket you tried to delete is not empty.
class BucketNotEmptyException extends CosException {}
