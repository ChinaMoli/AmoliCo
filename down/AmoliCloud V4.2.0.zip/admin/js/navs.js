{
	"contentManagement": [
		{
			"title": "网站设置",
			"icon": "&#xe631;",
			"href": "page/systemSetting/basicParameter.html",
			"spread": false
		},
		{
			"title": "文件管理",
			"icon": "&#xe7ae;",
			"href": "page/file/AdminFile.html",
			"spread": false
		}
	],
	"systemeSttings": [
		{
			"title": "网站设置",
			"icon": "&#xe631;",
			"href": "page/systemSetting/basicParameter.html",
			"spread": false
		}
	],
	"seraphApi": [
		{
			"title": "OSS配置教程",
			"icon": "icon-mokuai",
			"href": "https://wums.cn/archives/AMoliCloud-deploy.html",
			"spread": false
		},
		{
			"title": "COS配置教程",
			"icon": "icon-mokuai",
			"href": "https://wums.cn/archives/AmoliCloud-CosConfig.html",
			"spread": false
		}
	]
}