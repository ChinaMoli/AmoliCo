<?php
$bucket = "";
$endpoint = "";
$accessKeyId = "";
$accessKeySecret = "";