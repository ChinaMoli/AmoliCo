<?php
$name = "Amoli私人云";
$fname = "帮助您快速搭建私有云盘系统";
$keywords = "Amoli私人云,Amoli私有云,Amoli,AMoliCloud";
$url = "www.amoli.co";
$description = "Amoli私人云，一键快速搭建私有云盘系统，支持本地、阿里云OSS等对象存储在线管理";
$down = "on";
$gonggao = "欢迎使用Amoli私人云，一路陪伴，感恩有你！<li>这个是首页公告可以在后台进行更新</li>"
</li>";