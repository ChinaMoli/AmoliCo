<?php exit;?>{
    "name": "",
    "version": "",
    "loginTime": "",
    "user": "",
    "pass": "",
    "bucket": "",
    "endpoint": "",
    "accessKeyId": "",
    "accessKeySecret": "",
    "record": "",
    "indexpass": "",
    "ossdomain": ""
}